﻿
namespace paintingAppcation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pic_color = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.pictureBoxColorPalate = new System.Windows.Forms.PictureBox();
            this.buttonLine = new System.Windows.Forms.Button();
            this.buttonRectangle = new System.Windows.Forms.Button();
            this.buttonEclipse = new System.Windows.Forms.Button();
            this.buttonEraser = new System.Windows.Forms.Button();
            this.buttonPencil = new System.Windows.Forms.Button();
            this.buttonFill = new System.Windows.Forms.Button();
            this.buttonColor = new System.Windows.Forms.Button();
            this.pic = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxColorPalate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.buttonSave);
            this.panel1.Controls.Add(this.buttonClear);
            this.panel1.Controls.Add(this.pictureBoxColorPalate);
            this.panel1.Controls.Add(this.buttonLine);
            this.panel1.Controls.Add(this.buttonRectangle);
            this.panel1.Controls.Add(this.buttonEclipse);
            this.panel1.Controls.Add(this.buttonEraser);
            this.panel1.Controls.Add(this.buttonPencil);
            this.panel1.Controls.Add(this.buttonFill);
            this.panel1.Controls.Add(this.buttonColor);
            this.panel1.Controls.Add(this.pic_color);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1283, 138);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 687);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1283, 27);
            this.panel2.TabIndex = 1;
            // 
            // pic_color
            // 
            this.pic_color.BackColor = System.Drawing.Color.White;
            this.pic_color.Location = new System.Drawing.Point(410, 47);
            this.pic_color.Name = "pic_color";
            this.pic_color.Size = new System.Drawing.Size(55, 49);
            this.pic_color.TabIndex = 0;
            this.pic_color.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel3.Location = new System.Drawing.Point(508, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(646, 100);
            this.panel3.TabIndex = 3;
            // 
            // buttonSave
            // 
            this.buttonSave.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.buttonSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.buttonSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSave.ForeColor = System.Drawing.Color.White;
            this.buttonSave.Image = global::paintingAppcation.Properties.Resources.Save;
            this.buttonSave.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonSave.Location = new System.Drawing.Point(1172, 12);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(90, 47);
            this.buttonSave.TabIndex = 10;
            this.buttonSave.Text = "Save";
            this.buttonSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.buttonClear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.buttonClear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClear.ForeColor = System.Drawing.Color.White;
            this.buttonClear.Image = global::paintingAppcation.Properties.Resources.edit_clear;
            this.buttonClear.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonClear.Location = new System.Drawing.Point(1172, 65);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(90, 47);
            this.buttonClear.TabIndex = 9;
            this.buttonClear.Text = "Clear";
            this.buttonClear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonClear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // pictureBoxColorPalate
            // 
            this.pictureBoxColorPalate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxColorPalate.Image = global::paintingAppcation.Properties.Resources.color_palette;
            this.pictureBoxColorPalate.Location = new System.Drawing.Point(12, 12);
            this.pictureBoxColorPalate.Name = "pictureBoxColorPalate";
            this.pictureBoxColorPalate.Size = new System.Drawing.Size(378, 117);
            this.pictureBoxColorPalate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxColorPalate.TabIndex = 8;
            this.pictureBoxColorPalate.TabStop = false;
            this.pictureBoxColorPalate.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBoxColorPalate_MouseClick);
            // 
            // buttonLine
            // 
            this.buttonLine.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonLine.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.buttonLine.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonLine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLine.ForeColor = System.Drawing.Color.White;
            this.buttonLine.Image = global::paintingAppcation.Properties.Resources.line;
            this.buttonLine.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonLine.Location = new System.Drawing.Point(965, 24);
            this.buttonLine.Name = "buttonLine";
            this.buttonLine.Size = new System.Drawing.Size(83, 72);
            this.buttonLine.TabIndex = 7;
            this.buttonLine.Text = "Line";
            this.buttonLine.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonLine.UseVisualStyleBackColor = true;
            this.buttonLine.Click += new System.EventHandler(this.buttonLine_Click);
            // 
            // buttonRectangle
            // 
            this.buttonRectangle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonRectangle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.buttonRectangle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonRectangle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRectangle.ForeColor = System.Drawing.Color.White;
            this.buttonRectangle.Image = global::paintingAppcation.Properties.Resources.rectangle;
            this.buttonRectangle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonRectangle.Location = new System.Drawing.Point(1054, 24);
            this.buttonRectangle.Name = "buttonRectangle";
            this.buttonRectangle.Size = new System.Drawing.Size(90, 72);
            this.buttonRectangle.TabIndex = 6;
            this.buttonRectangle.Text = "Rectangle";
            this.buttonRectangle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonRectangle.UseVisualStyleBackColor = true;
            this.buttonRectangle.Click += new System.EventHandler(this.buttonRectangle_Click);
            // 
            // buttonEclipse
            // 
            this.buttonEclipse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonEclipse.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.buttonEclipse.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonEclipse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEclipse.ForeColor = System.Drawing.Color.White;
            this.buttonEclipse.Image = global::paintingAppcation.Properties.Resources.circle;
            this.buttonEclipse.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonEclipse.Location = new System.Drawing.Point(877, 24);
            this.buttonEclipse.Name = "buttonEclipse";
            this.buttonEclipse.Size = new System.Drawing.Size(84, 72);
            this.buttonEclipse.TabIndex = 5;
            this.buttonEclipse.Text = "Eclipse";
            this.buttonEclipse.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonEclipse.UseVisualStyleBackColor = true;
            this.buttonEclipse.Click += new System.EventHandler(this.buttonEclipse_Click);
            // 
            // buttonEraser
            // 
            this.buttonEraser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonEraser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.buttonEraser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonEraser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEraser.ForeColor = System.Drawing.Color.White;
            this.buttonEraser.Image = global::paintingAppcation.Properties.Resources.eraser;
            this.buttonEraser.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonEraser.Location = new System.Drawing.Point(785, 24);
            this.buttonEraser.Name = "buttonEraser";
            this.buttonEraser.Size = new System.Drawing.Size(86, 72);
            this.buttonEraser.TabIndex = 4;
            this.buttonEraser.Text = "Eraser";
            this.buttonEraser.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonEraser.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttonEraser.UseVisualStyleBackColor = true;
            this.buttonEraser.Click += new System.EventHandler(this.buttonEraser_Click);
            // 
            // buttonPencil
            // 
            this.buttonPencil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonPencil.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.buttonPencil.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonPencil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPencil.ForeColor = System.Drawing.Color.White;
            this.buttonPencil.Image = global::paintingAppcation.Properties.Resources.pencil;
            this.buttonPencil.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonPencil.Location = new System.Drawing.Point(696, 24);
            this.buttonPencil.Name = "buttonPencil";
            this.buttonPencil.Size = new System.Drawing.Size(83, 72);
            this.buttonPencil.TabIndex = 3;
            this.buttonPencil.Text = "Pencil";
            this.buttonPencil.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonPencil.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttonPencil.UseVisualStyleBackColor = true;
            this.buttonPencil.Click += new System.EventHandler(this.buttonPencil_Click);
            // 
            // buttonFill
            // 
            this.buttonFill.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonFill.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.buttonFill.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonFill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFill.ForeColor = System.Drawing.Color.White;
            this.buttonFill.Image = global::paintingAppcation.Properties.Resources.bucket;
            this.buttonFill.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonFill.Location = new System.Drawing.Point(603, 24);
            this.buttonFill.Name = "buttonFill";
            this.buttonFill.Size = new System.Drawing.Size(87, 72);
            this.buttonFill.TabIndex = 2;
            this.buttonFill.Text = "Fill";
            this.buttonFill.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonFill.UseVisualStyleBackColor = true;
            this.buttonFill.Click += new System.EventHandler(this.buttonFill_Click);
            // 
            // buttonColor
            // 
            this.buttonColor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonColor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.buttonColor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttonColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonColor.ForeColor = System.Drawing.Color.White;
            this.buttonColor.Image = global::paintingAppcation.Properties.Resources.color;
            this.buttonColor.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonColor.Location = new System.Drawing.Point(519, 24);
            this.buttonColor.Name = "buttonColor";
            this.buttonColor.Size = new System.Drawing.Size(78, 72);
            this.buttonColor.TabIndex = 1;
            this.buttonColor.Text = "Color";
            this.buttonColor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonColor.UseVisualStyleBackColor = true;
            this.buttonColor.Click += new System.EventHandler(this.buttonColor_Click);
            // 
            // pic
            // 
            this.pic.BackColor = System.Drawing.Color.White;
            this.pic.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pic.Location = new System.Drawing.Point(0, 0);
            this.pic.Name = "pic";
            this.pic.Size = new System.Drawing.Size(1283, 714);
            this.pic.TabIndex = 2;
            this.pic.TabStop = false;
            this.pic.Paint += new System.Windows.Forms.PaintEventHandler(this.pic_Paint);
            this.pic.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pic_MouseClick);
            this.pic.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pic_MouseDown);
            this.pic.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pic_MouseMove);
            this.pic.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pic_MouseUp);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1283, 714);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pic);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxColorPalate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonColor;
        private System.Windows.Forms.Button pic_color;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pic;
        private System.Windows.Forms.Button buttonFill;
        private System.Windows.Forms.Button buttonLine;
        private System.Windows.Forms.Button buttonRectangle;
        private System.Windows.Forms.Button buttonEclipse;
        private System.Windows.Forms.Button buttonEraser;
        private System.Windows.Forms.Button buttonPencil;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBoxColorPalate;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonSave;
    }
}

